from .logger import Colors, Logger, log_level

__version__ = '0.1.2'
__author__ = 'Alexey Tarasov'
